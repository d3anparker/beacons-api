﻿using Microsoft.AspNetCore.Mvc;

namespace Beacons.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BeaconController : ControllerBase
    {
        [HttpGet]
        public Task<IActionResult> GetAsync()
        {
            IActionResult result = Ok(new { Message = "Hello" });
            return Task.FromResult(result);
        }
    }
}
